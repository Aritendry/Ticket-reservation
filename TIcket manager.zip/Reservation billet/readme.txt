This one of my first project in python 

