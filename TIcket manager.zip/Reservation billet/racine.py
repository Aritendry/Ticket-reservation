class billet:
    def __init__(self,nom,date,lieu,nombre_deplace,id):
        self.nom = nom
        self.date = date
        self.lieu = lieu
        self.nombre_deplace:nombre_deplace
        self.id=id
class utilisateur:
    def __init__(self,nom,contact):
        self.nom = nom
        self.contact =contact

