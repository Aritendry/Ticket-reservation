from racine import *
print("TAPEZ HELP")
billet1=billet("concert d'eminem","2023-10-3","Londres","50","001")
billet2=billet("ambondrona","2023-12-12","Antananarivo-Plaza","180","007")
liste_billet= [billet1,billet2]
utilisateur1=utilisateur("aritendry","0349330804")
utilisateur2=utilisateur("jean-pierre-patrique","060040804")
liste_utilisateur = [utilisateur1,utilisateur2]
liste_reservation =[]
while True:
    print("_____________________________________")
    commande =str(input("Entrez votre commande : ")).lower()
    print("_____________________________________")
    if commande =="show_user":
        for user in liste_utilisateur:
            print("Voici tous les utilisateurs : ",user.nom)
    elif commande =="show_billet":
        for nb_billet in liste_billet:
            print("Voici tous les listes de billet : ",nb_billet.nom)
    elif commande =="reservation":
        while True:
            print("*********************************************")
            reservation_user = str(input("Choissez viotre utilisateur : ")).lower()
            print("*********************************************")
            if reservation_user == utilisateur1.nom:
                print("Vous avez selectionnez : ",utilisateur1.nom)
                break
            elif reservation_user == utilisateur2.nom:
                print("Vous avez selectionne : ",utilisateur2.nom)
                break
            else:
                print("Utilisateur introuvable")
        while True:
            print("**********************************")
            reservation_bilet = input("Choississez quel billet allez vous reservez : ").lower()
            print("**********************************")
            if reservation_bilet==billet1.nom or reservation_bilet==billet1.id:
                reservation_bilet=""+billet1.nom
                print("Vous avez reservez au",billet1.nom)
                break
            elif reservation_bilet==billet2.nom or reservation_bilet==billet2.id:
                reservation_bilet= ""+billet2.nom
                print("Vous avez reservez au",billet2.nom)
                break
            else:
                print("Verifiez votre ID ou nom du concert svp")
        reservation = reservation_user + " "+reservation_bilet
        liste_reservation.append(reservation)
    elif commande =="liste":
        print("voici les listes de reservation",liste_reservation)
    elif commande =="remove":
        print("Voici les listes pour connaitre l'indicage ;-; :\n",liste_reservation)
        n=int(input("Entrez l'indicage exacte : "))
        liste_reservation.remove(n)
        print("Voici la nouvelle liste :\n",liste_reservation)
    elif commande =="help":
        print("Voici tous les commandes : \nshow_user : affiche les listes des utilisateurs \nshow_billet : afiiche les listes de billet\nreservation : c'est la ou on choisit l'utilisateur et le liez a un billet \nliste: qui va lister les reservation(!!!!!!Attention si vous n'avez pas encore rien reservez rien n'apparaitra!!!!!!!!)\n J'espere avoir des retours sur ce devoir")



